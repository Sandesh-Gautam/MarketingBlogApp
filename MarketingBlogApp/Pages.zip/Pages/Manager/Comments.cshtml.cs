using MarketingBlogApp.Data;
using MarketingBlogApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MarketingBlogApp.Pages.Manager
{
    [Authorize(Roles = "Manager")]
    public class CommentsModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public CommentsModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Comment> Comments { get; set; }

        public async Task OnGetAsync()
        {
            Comments = await _context.Comments
                .Include(c => c.BlogPost)
                .Include(c => c.User)
                .ToListAsync();
        }
    }
}

using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MarketingBlogApp.Data;
using MarketingBlogApp.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MarketingBlogApp.Pages.Manager
{
    public class DashboardModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public DashboardModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<BlogPost> Posts { get; set; }
        public IList<Comment> Comments { get; set; }

        public async Task OnGetAsync()
        {
            Posts = await _context.BlogPosts
                .Include(p => p.Author)
                .ToListAsync();

            Comments = await _context.Comments
                .Include(c => c.User)
                .Include(c => c.BlogPost)
                .ToListAsync();
        }
    }
}

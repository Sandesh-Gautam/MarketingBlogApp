using MarketingBlogApp.Data;
using MarketingBlogApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MarketingBlogApp.Pages.Manager
{
    [Authorize(Roles = "Manager")]
    public class BlogPostsModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public BlogPostsModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<BlogPost> BlogPosts { get; set; }

        public async Task OnGetAsync()
        {
            BlogPosts = await _context.BlogPosts
                .Include(bp => bp.Author)
                .ToListAsync();
        }
    }
}

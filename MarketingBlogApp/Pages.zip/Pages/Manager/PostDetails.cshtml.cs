using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MarketingBlogApp.Data;
using MarketingBlogApp.Models;
using System;
using System.IO;
using System.Threading.Tasks;

namespace MarketingBlogApp.Pages.Manager
{
    public class PostDetailsModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public PostDetailsModel(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public BlogPost Post { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Post = await _context.BlogPosts
                .Include(p => p.Author)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (Post == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id, string reason, IFormFile proofImage)
        {
            var post = await _context.BlogPosts
                .Include(p => p.Author)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (post == null)
            {
                return NotFound();
            }

            string proofImageUrl = null;
            if (proofImage != null)
            {
                var fileName = Path.GetFileName(proofImage.FileName);
                var filePath = Path.Combine(_environment.WebRootPath, "uploads", fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await proofImage.CopyToAsync(stream);
                }

                proofImageUrl = $"/uploads/{fileName}";
            }

            var deletionReason = new DeletionReason
            {
                UserId = post.AuthorId,
                Reason = reason,
                DateIssued = DateTime.Now,
                IsResolved = false,
                ProofImageUrl = proofImageUrl
            };
            _context.DeletionReasons.Add(deletionReason);

            var warning = new Warning
            {
                UserId = post.AuthorId,
                Reason = reason,
                DateIssued = DateTime.Now,
                IsResolved = false
            };
            _context.Warnings.Add(warning);

            // Delete all related comments first
            var comments = _context.Comments.Where(c => c.BlogPostId == id);
            _context.Comments.RemoveRange(comments);

            _context.BlogPosts.Remove(post);

            await _context.SaveChangesAsync();

            return RedirectToPage("/Manager/Dashboard");
        }
    }
}
